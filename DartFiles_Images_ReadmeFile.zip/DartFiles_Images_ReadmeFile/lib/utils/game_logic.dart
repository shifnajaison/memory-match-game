import 'dart:math';
import '../models/card_model.dart';

class GameLogic {
  static List<CardModel> getCards() {
    List<String> images = [
      'assets/images/cat.png',
      'assets/images/dog.png',
      'assets/images/lion.png',
      'assets/images/redpanda.png',
      'assets/images/tiger.png',
      'assets/images/zibera.png',
    ];

    List<CardModel> cards = [];

    for (var image in images) {
      cards.add(CardModel(image: image));
      cards.add(CardModel(image: image));
    }

    cards.shuffle(Random());

    return cards;
  }
}