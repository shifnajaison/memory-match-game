import 'dart:async';
import 'package:flutter/material.dart';

import '../models/card_model.dart';
import '../utils/game_logic.dart';
import '../widgets/memory_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<CardModel> cards = [];

  CardModel? firstCard;
  CardModel? secondCard;

  int firstIndex = -1;
  int secondIndex = -1;
  int moves = 0;

  bool canFlip = true;

  @override
  void initState() {
    super.initState();
    startGame();
  }

  void startGame() {
    setState(() {
      cards = GameLogic.getCards();
      firstCard = null;
      secondCard = null;
      firstIndex = -1;
      secondIndex = -1;
      moves = 0;
      canFlip = true;
    });
  }

  void flipCard(int index) {
    if (!canFlip) return;
    if (cards[index].isFlipped || cards[index].isMatched) return;

    setState(() {
      cards[index].isFlipped = true;
    });

    if (firstCard == null) {
      firstCard = cards[index];
      firstIndex = index;
    } else {
      secondCard = cards[index];
      secondIndex = index;
      moves++;
      canFlip = false;
      checkMatch();
    }
  }

  void checkMatch() {
    if (firstCard!.image == secondCard!.image) {
      setState(() {
        firstCard!.isMatched = true;
        secondCard!.isMatched = true;
      });
      resetTurn();
    } else {
      Timer(const Duration(seconds: 1), () {
        setState(() {
          cards[firstIndex].isFlipped = false;
          cards[secondIndex].isFlipped = false;
        });
        resetTurn();
      });
    }
  }

  void resetTurn() {
    firstCard = null;
    secondCard = null;
    firstIndex = -1;
    secondIndex = -1;
    canFlip = true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Memory Match Game"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          const SizedBox(height: 10),
          Text(
            "Moves: $moves",
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(10),
              itemCount: cards.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemBuilder: (context, index) {
                return MemoryCard(
                  card: cards[index],
                  onTap: () => flipCard(index),
                );
              },
            ),
          ),
          ElevatedButton(
            onPressed: startGame,
            child: const Text("Restart Game"),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}